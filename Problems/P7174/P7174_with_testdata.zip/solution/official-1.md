# 银行卡前缀匹配

算法标签：字符串,哈希表,字典树

算法难度：$4 / 10$

## 解题思路

给定 $n$ 条互不相同的数字前缀及其银行名，对 $m$ 个卡号分别找出**最长**匹配前缀对应的银行；没有任何前缀匹配则输出 $UNKNOWN$。

1. 把每条规则放进哈希表：$prefix\to bank$。前缀互不相同，不会冲突。
2. 前缀最长只有 $20$，因此对每个卡号只需枚举长度 $1$ 到 $\min(20,|card|)$ 的开头子串。
3. 从长到短枚举，第一次在哈希表里命中的就是最长前缀；全部未命中则是 $UNKNOWN$。
4. 也可以建一棵十叉字典树，沿卡号往下走，每经过一个前缀结尾就更新答案，效果相同。
5. 常见假解：按输入顺序取第一条匹配（不一定最长）；按输入顺序取最后一条匹配；对每个卡号扫全部 $n$ 条规则导致 $O(nm)$ 超时。

## 复杂度分析

- 时间复杂度：$O(n\cdot L + m\cdot L^2)$，其中 $L\le 20$ 为前缀最大长度。哈希表也可用字典树做到 $O((n+m)L)$。
- 空间复杂度：$O(n\cdot L)$。

## 代码实现

### Python

```python
def solve(prefixes, cards):
    """把所有前缀放进哈希表。
    每个卡号从长到短枚举可能的前缀（最长 20），第一次命中就是最长匹配。
    全部长度都没有命中则是 UNKNOWN。
    """
    mp = {}
    for prefix, bank in prefixes:
        mp[prefix] = bank
    answers = []
    for card in cards:
        ans = "UNKNOWN"
        # 前缀最长只有 20，卡号更短时只枚举到卡号长度
        upper = len(card)
        if upper > 20:
            upper = 20
        L = upper
        while L >= 1:
            pref = card[:L]
            if pref in mp:
                ans = mp[pref]
                break
            L -= 1
        answers.append(ans)
    return answers


def main():
    # 先读 n 条规则，再读 m 个卡号，每个卡号输出一行银行名
    n = int(input())
    prefixes = []
    for _ in range(n):
        parts = input().split()
        prefixes.append((parts[0], parts[1]))
    m = int(input())
    cards = []
    for _ in range(m):
        cards.append(input().strip())
    answers = solve(prefixes, cards)
    for name in answers:
        print(name)


if __name__ == "__main__":
    main()
```

### Java

```java
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.StringTokenizer;

public class Main {
    // 哈希表存前缀到银行；每个卡号从长到短试前缀，第一次命中即最长匹配
    static String[] solve(String[] prefixes, String[] banks, String[] cards) {
        HashMap<String, String> mp = new HashMap<String, String>();
        for (int i = 0; i < prefixes.length; i++) {
            mp.put(prefixes[i], banks[i]);
        }
        String[] answers = new String[cards.length];
        for (int i = 0; i < cards.length; i++) {
            String card = cards[i];
            String ans = "UNKNOWN";
            int upper = card.length();
            if (upper > 20) {
                upper = 20;
            }
            // 从长到短枚举，避免取到输入顺序里较短的那条规则
            for (int L = upper; L >= 1; L--) {
                String pref = card.substring(0, L);
                String bank = mp.get(pref);
                if (bank != null) {
                    ans = bank;
                    break;
                }
            }
            answers[i] = ans;
        }
        return answers;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine().trim());
        String[] prefixes = new String[n];
        String[] banks = new String[n];
        for (int i = 0; i < n; i++) {
            StringTokenizer st = new StringTokenizer(br.readLine());
            prefixes[i] = st.nextToken();
            banks[i] = st.nextToken();
        }
        int m = Integer.parseInt(br.readLine().trim());
        String[] cards = new String[m];
        for (int i = 0; i < m; i++) {
            cards[i] = br.readLine().trim();
        }
        String[] answers = solve(prefixes, banks, cards);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < answers.length; i++) {
            sb.append(answers[i]).append('\n');
        }
        System.out.print(sb.toString());
    }
}
```

### C++

```cpp
#include <iostream>
#include <string>
#include <vector>
#include <unordered_map>
#include <utility>
using namespace std;

// 哈希表存前缀到银行；每个卡号从长到短试前缀，第一次命中即最长匹配
vector<string> solve(const vector<pair<string, string>>& prefixes,
                     const vector<string>& cards) {
    unordered_map<string, string> mp;
    mp.reserve(prefixes.size() * 2 + 1);
    for (int i = 0; i < (int)prefixes.size(); i++) {
        mp[prefixes[i].first] = prefixes[i].second;
    }
    vector<string> answers;
    answers.reserve(cards.size());
    for (int i = 0; i < (int)cards.size(); i++) {
        const string& card = cards[i];
        string ans = "UNKNOWN";
        int upper = (int)card.size();
        if (upper > 20) {
            upper = 20;
        }
        // 从长到短，保证取到最长前缀，而不是输入顺序里的第一条
        for (int L = upper; L >= 1; L--) {
            string pref = card.substr(0, L);
            unordered_map<string, string>::iterator it = mp.find(pref);
            if (it != mp.end()) {
                ans = it->second;
                break;
            }
        }
        answers.push_back(ans);
    }
    return answers;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    vector<pair<string, string>> prefixes(n);
    for (int i = 0; i < n; i++) {
        cin >> prefixes[i].first >> prefixes[i].second;
    }
    int m;
    cin >> m;
    vector<string> cards(m);
    for (int i = 0; i < m; i++) {
        cin >> cards[i];
    }
    vector<string> answers = solve(prefixes, cards);
    for (int i = 0; i < (int)answers.size(); i++) {
        cout << answers[i] << '\n';
    }
    return 0;
}
```
