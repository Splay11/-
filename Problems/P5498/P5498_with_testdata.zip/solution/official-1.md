# 枚举暴力解法

这道题的正解是 $CDQ$ 分治配合 $树状数组$，但是我们用朴素解法 $每次查询扫描上游区间$ 也能在考试时拿到一定的分数。

查询工位 $x$ 时，上游窗口是 $[x-D,x-1]$（左端不足则取 $1$，空区间答案为 $0$）。把当前重量满足 $w_j\le w_x-K$ 的工位个数统计出来即可。更新操作直接改 $w_x$。

朴素做法：用数组维护当前重量。遇到 `1 x y` 就赋值；遇到 `2 x` 就从左到右扫一遍窗口。时间 $O(mD)$。$n$、$m$ 较小时可以通过；接近 $10^5$ 且 $D$ 很大时会超时，需要后面的正解。

## 枚举解法
#code-switcher
```python
def count_low(n, d, k, w, ops):
    # 用数组记下每个工位当前重量，下标从 1 开始
    cur = [0] + list(w)
    ans = []
    for op in ops:
        if op[0] == 1:
            # 把工位 x 的重量改成 y
            x = op[1]
            y = op[2]
            cur[x] = y
        else:
            x = op[1]
            left = x - d
            if left < 1:
                left = 1
            right = x - 1
            # 阈值是当前 w_x - K，窗口内重量不超过它的都算偏低
            thresh = cur[x] - k
            cnt = 0
            for j in range(left, right + 1):
                if cur[j] <= thresh:
                    cnt += 1
            ans.append(cnt)
    return ans


def main():
    parts = list(map(int, input().split()))
    n, m, d, k = parts[0], parts[1], parts[2], parts[3]
    w = list(map(int, input().split()))
    ops = []
    for _ in range(m):
        ops.append(list(map(int, input().split())))
    out = count_low(n, d, k, w[:n], ops)
    for x in out:
        print(x)


if __name__ == "__main__":
    main()
```
```cpp
#include <iostream>
#include <vector>
using namespace std;

vector<int> countLow(int n, int d, long long k, vector<long long>& cur, const vector<vector<long long> >& ops) {
    // 扫描每个询问的上游窗口
    vector<int> ans;
    for (size_t t = 0; t < ops.size(); t++) {
        int op = (int)ops[t][0];
        if (op == 1) {
            int x = (int)ops[t][1];
            long long y = ops[t][2];
            cur[x] = y;
        } else {
            int x = (int)ops[t][1];
            int left = x - d;
            if (left < 1) {
                left = 1;
            }
            int right = x - 1;
            long long thresh = cur[x] - k;
            int cnt = 0;
            for (int j = left; j <= right; j++) {
                if (cur[j] <= thresh) {
                    cnt++;
                }
            }
            ans.push_back(cnt);
        }
    }
    return ans;
}

int main() {
    int n, m, d;
    long long k;
    cin >> n >> m >> d >> k;
    vector<long long> cur(n + 1);
    for (int i = 1; i <= n; i++) {
        cin >> cur[i];
    }
    vector<vector<long long> > ops;
    for (int i = 0; i < m; i++) {
        int op;
        cin >> op;
        vector<long long> row;
        row.push_back(op);
        if (op == 1) {
            int x;
            long long y;
            cin >> x >> y;
            row.push_back(x);
            row.push_back(y);
        } else {
            int x;
            cin >> x;
            row.push_back(x);
        }
        ops.push_back(row);
    }
    vector<int> out = countLow(n, d, k, cur, ops);
    for (size_t i = 0; i < out.size(); i++) {
        cout << out[i] << "\n";
    }
    return 0;
}
```
```java
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    static ArrayList<Integer> countLow(int n, int d, long k, long[] cur, ArrayList<long[]> ops) {
        // 扫描每个询问的上游窗口
        ArrayList<Integer> ans = new ArrayList<Integer>();
        for (int t = 0; t < ops.size(); t++) {
            long[] op = ops.get(t);
            if (op[0] == 1) {
                int x = (int) op[1];
                cur[x] = op[2];
            } else {
                int x = (int) op[1];
                int left = x - d;
                if (left < 1) {
                    left = 1;
                }
                int right = x - 1;
                long thresh = cur[x] - k;
                int cnt = 0;
                for (int j = left; j <= right; j++) {
                    if (cur[j] <= thresh) {
                        cnt++;
                    }
                }
                ans.add(cnt);
            }
        }
        return ans;
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        int m = in.nextInt();
        int d = in.nextInt();
        long k = in.nextLong();
        long[] cur = new long[n + 1];
        for (int i = 1; i <= n; i++) {
            cur[i] = in.nextLong();
        }
        ArrayList<long[]> ops = new ArrayList<long[]>();
        for (int i = 0; i < m; i++) {
            int op = in.nextInt();
            if (op == 1) {
                int x = in.nextInt();
                long y = in.nextLong();
                ops.add(new long[] {1, x, y});
            } else {
                int x = in.nextInt();
                ops.add(new long[] {2, x});
            }
        }
        ArrayList<Integer> out = countLow(n, d, k, cur, ops);
        for (int i = 0; i < out.size(); i++) {
            System.out.println(out.get(i));
        }
    }
}
```
#code-switcher
# 正确解法

## 题目分析

每次询问要统计：编号落在 $[x-D,x-1]$、且当前重量 $\le w_x-K$ 的工位数。重量会随更新改变，所以这是带修改的二维计数：一维是工位编号，一维是重量。

把每个时刻的改点和询问都做成事件，按时间顺序排好。初始重量当成时刻 $0$ 的 $n$ 次插入。一次更新拆成「删掉旧重量、插入新重量」两个改点。

用 $CDQ$ 分治处理时间先后：

1. 把事件序列按时间对半切开，先递归处理左半段和右半段。
2. 左半段里的改点，一定发生在右半段询问之前，可以把它们贡献给右半段询问。
3. 两边都按重量从小到大排序，双指针把「重量不超过当前询问阈值」的改点插入树状数组。
4. 树状数组下标是工位编号，询问时查询窗口 $[x-D,x-1]$ 的点数。
5. 统计完后把树状数组回滚，避免污染其他分治区间。

重量可能到 $10^9$，阈值 $w_x-K$ 可能为负，用 $64$ 位整数存放。

## 复杂度分析

* 时间复杂度：$O((n+m)\log^2(n+m))$。分治 $O(\log(n+m))$ 层，每层按重量排序并在树状数组上操作。
* 空间复杂度：$O(n+m)$。存事件、树状数组和答案。

## 代码实现

### Python

```python
class Fenwick:
    def __init__(self, n):
        # 树状数组下标对应工位编号 1..n，存的是「当前有效的点权个数」
        self.n = n
        self.c = [0] * (n + 1)

    def add(self, i, v):
        # 在工位 i 上加上 v：插入点权时 v=1，撤销时 v=-1
        while i <= self.n:
            self.c[i] += v
            i += i & -i

    def pre(self, i):
        # 前缀和：编号 1..i 上已经插入的点数
        s = 0
        while i > 0:
            s += self.c[i]
            i -= i & -i
        return s

    def rng(self, left, right):
        # 区间 [left, right] 内的点数；空区间直接 0
        if left > right:
            return 0
        return self.pre(right) - self.pre(left - 1)


def solve(n, d, k, w, ops):
    # 事件：0 表示改点，1 表示询问。加入顺序就是时间顺序
    events = []
    cur = [0] + list(w)
    # 初始重量当成时刻 0 的 n 次插入
    for i in range(1, n + 1):
        events.append((0, cur[i], i, 1, 0, 0, -1))
    qid = 0
    for op in ops:
        if op[0] == 1:
            x = op[1]
            y = op[2]
            # 先删掉旧重量，再插入新重量
            events.append((0, cur[x], x, -1, 0, 0, -1))
            events.append((0, y, x, 1, 0, 0, -1))
            cur[x] = y
        else:
            x = op[1]
            left = x - d
            if left < 1:
                left = 1
            right = x - 1
            # 阈值是当前 w_x - K
            events.append((1, cur[x] - k, 0, 0, left, right, qid))
            qid += 1
    ans = [0] * qid
    bit = Fenwick(n)
    ids = list(range(len(events)))

    def cdq(l, r):
        # 按时间二分：左半段已经发生的改点，才能贡献给右半段的询问
        if l >= r:
            return
        mid = (l + r) // 2
        cdq(l, mid)
        cdq(mid + 1, r)
        left_upd = []
        right_qry = []
        for i in range(l, mid + 1):
            e = events[ids[i]]
            if e[0] == 0:
                left_upd.append(ids[i])
        for i in range(mid + 1, r + 1):
            e = events[ids[i]]
            if e[0] == 1:
                right_qry.append(ids[i])
        left_upd.sort(key=lambda t: events[t][1])
        right_qry.sort(key=lambda t: events[t][1])
        p = 0
        used = []
        for qi in right_qry:
            thresh = events[qi][1]
            while p < len(left_upd) and events[left_upd[p]][1] <= thresh:
                ui = left_upd[p]
                bit.add(events[ui][2], events[ui][3])
                used.append(ui)
                p += 1
            ql = events[qi][4]
            qr = events[qi][5]
            qn = events[qi][6]
            ans[qn] += bit.rng(ql, qr)
        for ui in used:
            bit.add(events[ui][2], -events[ui][3])

    if events:
        cdq(0, len(events) - 1)
    return ans


def main():
    parts = list(map(int, input().split()))
    n, m, d, k = parts[0], parts[1], parts[2], parts[3]
    w = list(map(int, input().split()))
    ops = []
    for _ in range(m):
        ops.append(list(map(int, input().split())))
    out = solve(n, d, k, w[:n], ops)
    for x in out:
        print(x)


if __name__ == "__main__":
    main()
```

### Java

```java
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.StringTokenizer;

public class Main {
    static class Event {
        int kind;
        long val;
        int pos;
        int delta;
        int left;
        int right;
        int qid;
    }

    static class Fenwick {
        int n;
        int[] c;

        Fenwick(int n) {
            this.n = n;
            c = new int[n + 1];
        }

        void add(int i, int v) {
            // 在工位 i 上加上 v：插入为 +1，撤销为 -1
            while (i <= n) {
                c[i] += v;
                i += i & -i;
            }
        }

        int pre(int i) {
            int s = 0;
            while (i > 0) {
                s += c[i];
                i -= i & -i;
            }
            return s;
        }

        int rng(int left, int right) {
            if (left > right) {
                return 0;
            }
            return pre(right) - pre(left - 1);
        }
    }

    static ArrayList<Event> events;
    static int[] ids;
    static int[] ans;
    static Fenwick bit;

    static void cdq(int l, int r) {
        // 按时间二分：左半段改点贡献给右半段询问
        if (l >= r) {
            return;
        }
        int mid = (l + r) / 2;
        cdq(l, mid);
        cdq(mid + 1, r);
        ArrayList<Integer> leftUpd = new ArrayList<Integer>();
        ArrayList<Integer> rightQry = new ArrayList<Integer>();
        for (int i = l; i <= mid; i++) {
            if (events.get(ids[i]).kind == 0) {
                leftUpd.add(ids[i]);
            }
        }
        for (int i = mid + 1; i <= r; i++) {
            if (events.get(ids[i]).kind == 1) {
                rightQry.add(ids[i]);
            }
        }
        Collections.sort(leftUpd, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) {
                if (events.get(a).val < events.get(b).val) {
                    return -1;
                }
                if (events.get(a).val > events.get(b).val) {
                    return 1;
                }
                return 0;
            }
        });
        Collections.sort(rightQry, new Comparator<Integer>() {
            public int compare(Integer a, Integer b) {
                if (events.get(a).val < events.get(b).val) {
                    return -1;
                }
                if (events.get(a).val > events.get(b).val) {
                    return 1;
                }
                return 0;
            }
        });
        int p = 0;
        ArrayList<Integer> used = new ArrayList<Integer>();
        for (int t = 0; t < rightQry.size(); t++) {
            int qi = rightQry.get(t);
            while (p < leftUpd.size() && events.get(leftUpd.get(p)).val <= events.get(qi).val) {
                int ui = leftUpd.get(p);
                bit.add(events.get(ui).pos, events.get(ui).delta);
                used.add(ui);
                p++;
            }
            ans[events.get(qi).qid] += bit.rng(events.get(qi).left, events.get(qi).right);
        }
        for (int t = 0; t < used.size(); t++) {
            int ui = used.get(t);
            bit.add(events.get(ui).pos, -events.get(ui).delta);
        }
    }

    public static void main(String[] args) throws IOException {
        // n、m 到 1e5，用 BufferedReader 读入
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        StringTokenizer st = new StringTokenizer(br.readLine());
        int n = Integer.parseInt(st.nextToken());
        int m = Integer.parseInt(st.nextToken());
        int d = Integer.parseInt(st.nextToken());
        long k = Long.parseLong(st.nextToken());
        st = new StringTokenizer(br.readLine());
        long[] cur = new long[n + 1];
        events = new ArrayList<Event>();
        for (int i = 1; i <= n; i++) {
            cur[i] = Long.parseLong(st.nextToken());
            Event e = new Event();
            e.kind = 0;
            e.val = cur[i];
            e.pos = i;
            e.delta = 1;
            e.qid = -1;
            events.add(e);
        }
        int qid = 0;
        for (int i = 0; i < m; i++) {
            st = new StringTokenizer(br.readLine());
            int op = Integer.parseInt(st.nextToken());
            if (op == 1) {
                int x = Integer.parseInt(st.nextToken());
                long y = Long.parseLong(st.nextToken());
                Event a = new Event();
                a.kind = 0;
                a.val = cur[x];
                a.pos = x;
                a.delta = -1;
                a.qid = -1;
                events.add(a);
                Event b = new Event();
                b.kind = 0;
                b.val = y;
                b.pos = x;
                b.delta = 1;
                b.qid = -1;
                events.add(b);
                cur[x] = y;
            } else {
                int x = Integer.parseInt(st.nextToken());
                Event q = new Event();
                q.kind = 1;
                q.val = cur[x] - k;
                q.left = x - d;
                if (q.left < 1) {
                    q.left = 1;
                }
                q.right = x - 1;
                q.qid = qid++;
                events.add(q);
            }
        }
        ans = new int[qid];
        bit = new Fenwick(n);
        int sz = events.size();
        ids = new int[sz];
        for (int i = 0; i < sz; i++) {
            ids[i] = i;
        }
        if (sz > 0) {
            cdq(0, sz - 1);
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < qid; i++) {
            sb.append(ans[i]).append('\n');
        }
        System.out.print(sb.toString());
    }
}
```

### C++

```cpp
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

struct Event {
    int kind;
    long long val;
    int pos;
    int delta;
    int left;
    int right;
    int qid;
};

struct Fenwick {
    int n;
    vector<int> c;
    Fenwick(int n_ = 0) { init(n_); }
    void init(int n_) {
        n = n_;
        c.assign(n + 1, 0);
    }
    void add(int i, int v) {
        // 在工位 i 上加上 v：插入为 +1，撤销为 -1
        while (i <= n) {
            c[i] += v;
            i += i & -i;
        }
    }
    int pre(int i) {
        int s = 0;
        while (i > 0) {
            s += c[i];
            i -= i & -i;
        }
        return s;
    }
    int rng(int left, int right) {
        if (left > right) {
            return 0;
        }
        return pre(right) - pre(left - 1);
    }
};

vector<Event> events;
vector<int> ids;
vector<int> ans;
Fenwick bit;

bool cmpVal(int a, int b) {
    return events[a].val < events[b].val;
}

void cdq(int l, int r) {
    // 按时间二分：左半段改点贡献给右半段询问
    if (l >= r) {
        return;
    }
    int mid = (l + r) / 2;
    cdq(l, mid);
    cdq(mid + 1, r);
    vector<int> leftUpd;
    vector<int> rightQry;
    for (int i = l; i <= mid; i++) {
        if (events[ids[i]].kind == 0) {
            leftUpd.push_back(ids[i]);
        }
    }
    for (int i = mid + 1; i <= r; i++) {
        if (events[ids[i]].kind == 1) {
            rightQry.push_back(ids[i]);
        }
    }
    sort(leftUpd.begin(), leftUpd.end(), cmpVal);
    sort(rightQry.begin(), rightQry.end(), cmpVal);
    int p = 0;
    vector<int> used;
    for (size_t t = 0; t < rightQry.size(); t++) {
        int qi = rightQry[t];
        while (p < (int)leftUpd.size() && events[leftUpd[p]].val <= events[qi].val) {
            int ui = leftUpd[p];
            bit.add(events[ui].pos, events[ui].delta);
            used.push_back(ui);
            p++;
        }
        ans[events[qi].qid] += bit.rng(events[qi].left, events[qi].right);
    }
    for (size_t t = 0; t < used.size(); t++) {
        int ui = used[t];
        bit.add(events[ui].pos, -events[ui].delta);
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    int n, m, d;
    long long k;
    cin >> n >> m >> d >> k;
    vector<long long> cur(n + 1);
    for (int i = 1; i <= n; i++) {
        cin >> cur[i];
        Event e;
        e.kind = 0;
        e.val = cur[i];
        e.pos = i;
        e.delta = 1;
        e.left = 0;
        e.right = 0;
        e.qid = -1;
        events.push_back(e);
    }
    int qid = 0;
    for (int i = 0; i < m; i++) {
        int op;
        cin >> op;
        if (op == 1) {
            int x;
            long long y;
            cin >> x >> y;
            Event a;
            a.kind = 0;
            a.val = cur[x];
            a.pos = x;
            a.delta = -1;
            a.left = 0;
            a.right = 0;
            a.qid = -1;
            events.push_back(a);
            Event b;
            b.kind = 0;
            b.val = y;
            b.pos = x;
            b.delta = 1;
            b.left = 0;
            b.right = 0;
            b.qid = -1;
            events.push_back(b);
            cur[x] = y;
        } else {
            int x;
            cin >> x;
            Event q;
            q.kind = 1;
            q.val = cur[x] - k;
            q.pos = 0;
            q.delta = 0;
            q.left = x - d;
            if (q.left < 1) {
                q.left = 1;
            }
            q.right = x - 1;
            q.qid = qid++;
            events.push_back(q);
        }
    }
    ans.assign(qid, 0);
    bit.init(n);
    int sz = (int)events.size();
    ids.resize(sz);
    for (int i = 0; i < sz; i++) {
        ids[i] = i;
    }
    if (sz > 0) {
        cdq(0, sz - 1);
    }
    for (int i = 0; i < qid; i++) {
        cout << ans[i] << "\n";
    }
    return 0;
}
```
