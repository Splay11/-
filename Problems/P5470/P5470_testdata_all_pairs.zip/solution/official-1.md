# 推理模型分批

一句话总结：把先后约束建成有向无环图，按拓扑序做动态规划，最少波次等于最长依赖链上的模型个数。

算法标签：拓扑排序、动态规划、有向无环图、图论

算法难度：$4 / 10$

## 解题思路

同一波次里的模型必须互不依赖，因此每一条约束 $u\to v$（$v$ 等 $u$）都会把 $v$ 至少推到比 $u$ 更靠后的一波。最少波次就是图上最长那条链的长度。

1. 建图。第 $k$ 条 $rel[k]=[u,v]$ 表示 $u$ 必须排在 $v$ 前面，连有向边 $u\to v$。题面保证无环，所以这是一张 DAG。
2. 设 $dp[x]$ 为「以编号 $x$ 结尾的最长链包含几个模型」。没有入边的点 $dp=1$，它们可以放进第一波。
3. 按拓扑序松弛：处理完 $u$ 之后，对每条边 $u\to v$ 做 $dp[v]=\max(dp[v],dp[u]+1)$。入度降到 $0$ 的点入队，即 Kahn 算法。
4. 答案是 $\max(dp[1..p])$。全无约束时所有点都是孤立点，答案为 $1$；一条贯穿 $p$ 个点的链，答案为 $p$。
5. 常见假解：把图当成无向图做 BFS；输出连通块个数；输出最大入度加一（链的入度全是 $1$，答案却是 $p$）；把边方向建反。

## 复杂度分析

- 时间复杂度：$O(p+e)$。每个点和每条边进出队列一次。
- 空间复杂度：$O(p+e)$。邻接表、入度与 $dp$。

$p\le 10^{5}$，$e\le 1.5\times 10^{6}$，线性扫描即可。评测时限 $3$ 秒、内存 $512$ MB。Java 边数较大，用 `BufferedReader` 读入。

## 代码实现

### Python

```python
from collections import deque


def min_waves(p, rel):
    # 最少波次 = DAG 上最长链包含的模型个数
    # rel 中 (u, v) 表示 v 必须等 u 先结束，建边 u -> v
    graph = [[] for _ in range(p + 1)]
    indeg = [0] * (p + 1)
    for u, v in rel:
        graph[u].append(v)
        indeg[v] += 1

    # dp[x]：以 x 结尾的最长链长度；孤立点为 1
    dp = [1] * (p + 1)
    q = deque()
    for i in range(1, p + 1):
        if indeg[i] == 0:
            q.append(i)

    while q:
        u = q.popleft()
        for v in graph[u]:
            # 先走完 u 再走 v，链长至少是 dp[u] + 1
            if dp[u] + 1 > dp[v]:
                dp[v] = dp[u] + 1
            indeg[v] -= 1
            if indeg[v] == 0:
                q.append(v)

    ans = 1
    for i in range(1, p + 1):
        if dp[i] > ans:
            ans = dp[i]
    return ans


def main():
    p, e = map(int, input().split())
    rel = []
    for _ in range(e):
        u, v = map(int, input().split())
        rel.append((u, v))
    print(min_waves(p, rel))


if __name__ == "__main__":
    main()
```

### Java

```java
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class Main {
    // 最少波次 = DAG 上最长链包含的模型个数
    static int minWaves(int p, int[][] rel) {
        ArrayList<Integer>[] graph = new ArrayList[p + 1];
        for (int i = 1; i <= p; i++) {
            graph[i] = new ArrayList<Integer>();
        }
        int[] indeg = new int[p + 1];
        for (int k = 0; k < rel.length; k++) {
            int u = rel[k][0];
            int v = rel[k][1];
            graph[u].add(v);
            indeg[v]++;
        }

        // dp[x]：以 x 结尾的最长链长度；孤立点为 1
        int[] dp = new int[p + 1];
        for (int i = 1; i <= p; i++) {
            dp[i] = 1;
        }
        ArrayDeque<Integer> q = new ArrayDeque<Integer>();
        for (int i = 1; i <= p; i++) {
            if (indeg[i] == 0) {
                q.add(i);
            }
        }

        while (!q.isEmpty()) {
            int u = q.poll();
            for (int v : graph[u]) {
                // 先走完 u 再走 v，链长至少是 dp[u] + 1
                if (dp[u] + 1 > dp[v]) {
                    dp[v] = dp[u] + 1;
                }
                indeg[v]--;
                if (indeg[v] == 0) {
                    q.add(v);
                }
            }
        }

        int ans = 1;
        for (int i = 1; i <= p; i++) {
            if (dp[i] > ans) {
                ans = dp[i];
            }
        }
        return ans;
    }

    public static void main(String[] args) throws IOException {
        // 边数到 1.5e6，用 BufferedReader 避免 Scanner 超时
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        StringTokenizer st = new StringTokenizer(br.readLine());
        int p = Integer.parseInt(st.nextToken());
        int e = Integer.parseInt(st.nextToken());
        int[][] rel = new int[e][2];
        for (int k = 0; k < e; k++) {
            st = new StringTokenizer(br.readLine());
            rel[k][0] = Integer.parseInt(st.nextToken());
            rel[k][1] = Integer.parseInt(st.nextToken());
        }
        System.out.println(minWaves(p, rel));
    }
}
```

### C++

```cpp
#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

// 最少波次 = DAG 上最长链包含的模型个数
int minWaves(int p, const vector<pair<int, int>>& rel) {
    vector<vector<int>> graph(p + 1);
    vector<int> indeg(p + 1, 0);
    for (size_t k = 0; k < rel.size(); k++) {
        int u = rel[k].first;
        int v = rel[k].second;
        graph[u].push_back(v);
        indeg[v]++;
    }

    // dp[x]：以 x 结尾的最长链长度；孤立点为 1
    vector<int> dp(p + 1, 1);
    queue<int> q;
    for (int i = 1; i <= p; i++) {
        if (indeg[i] == 0) {
            q.push(i);
        }
    }

    while (!q.empty()) {
        int u = q.front();
        q.pop();
        for (int v : graph[u]) {
            // 先走完 u 再走 v，链长至少是 dp[u] + 1
            dp[v] = max(dp[v], dp[u] + 1);
            indeg[v]--;
            if (indeg[v] == 0) {
                q.push(v);
            }
        }
    }

    int ans = 1;
    for (int i = 1; i <= p; i++) {
        ans = max(ans, dp[i]);
    }
    return ans;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int p, e;
    cin >> p >> e;
    vector<pair<int, int>> rel;
    rel.reserve(e);
    for (int k = 0; k < e; k++) {
        int u, v;
        cin >> u >> v;
        rel.push_back({u, v});
    }
    cout << minWaves(p, rel) << "\n";
    return 0;
}
```
